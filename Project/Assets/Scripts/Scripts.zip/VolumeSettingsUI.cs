using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;

public class VolumeSettingsUI : MonoBehaviour
{
    [Header("UI ����")]
    [SerializeField] private Slider volumeSlider;     // VolumeSlider
    [SerializeField] private Image volumeIcon;        // VolumeIcon

    [Header("������ 4�� (0%, 1~33%, 34~66%, 67~100%)")]
    [SerializeField] private Sprite iconMute;
    [SerializeField] private Sprite iconLow;
    [SerializeField] private Sprite iconMid;
    [SerializeField] private Sprite iconHigh;

    [Header("AudioMixer ���(����)")]
    [SerializeField] private AudioMixer audioMixer;
    [SerializeField] private string mixerParamName = "MasterVolume"; // ���� �Ķ���� �̸�

    private const string PrefKey = "masterVolume01"; // 0~1 ����

    private void Awake()
    {
        if (volumeSlider != null)
            volumeSlider.onValueChanged.AddListener(OnVolumeChanged);
    }

    private void OnDestroy()
    {
        if (volumeSlider != null)
            volumeSlider.onValueChanged.RemoveListener(OnVolumeChanged);
    }

    private void OnEnable()
    {
        // �ɼ� �г� ���� �� ����� ������ ����ȭ
        float v = PlayerPrefs.GetFloat(PrefKey, 1f);
        if (volumeSlider != null)
            volumeSlider.SetValueWithoutNotify(v);

        ApplyVolume(v);
        UpdateIcon(v);
    }

    private void OnVolumeChanged(float v)
    {
        ApplyVolume(v);
        UpdateIcon(v);

        PlayerPrefs.SetFloat(PrefKey, v);
        PlayerPrefs.Save();
    }

    private void ApplyVolume(float v01)
    {
        // 1) AudioMixer�� ����� ������ �װɷ� ����(��õ)
        if (audioMixer != null)
        {
            // 0�̸� -80dB(���� ����), �� �ܴ� �α� ������
            float db = (v01 <= 0.0001f) ? -80f : Mathf.Log10(v01) * 20f;
            audioMixer.SetFloat(mixerParamName, db);
            return;
        }

        // 2) �ƴϸ� �����ϰ� ��ü ����
        AudioListener.volume = v01;
    }

    private void UpdateIcon(float v01)
    {
        if (volumeIcon == null) return;

        if (v01 <= 0.0001f) volumeIcon.sprite = iconMute;
        else if (v01 <= 0.33f) volumeIcon.sprite = iconLow;
        else if (v01 <= 0.66f) volumeIcon.sprite = iconMid;
        else volumeIcon.sprite = iconHigh;
    }
}
