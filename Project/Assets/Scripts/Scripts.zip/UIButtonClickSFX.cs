using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UIButtonClickSFX : MonoBehaviour
{
    public static UIButtonClickSFX I;

    [Header("Ŭ�� ȿ����(�ϳ���)")]
    public AudioClip clickClip;

    [Header("����")]
    [Range(0f, 1f)] public float volume = 1f;

    [Header("�ߺ� ��� ������")]
    private readonly HashSet<int> _hooked = new();

    private AudioSource _source;

    private void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);

        _source = GetComponent<AudioSource>();
        if (_source == null) _source = gameObject.AddComponent<AudioSource>();

        _source.playOnAwake = false;
        _source.loop = false;
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void Start()
    {
        HookAllButtonsInScene();
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // �� �� �ε�� ������ ��ư �ٽ� ��
        HookAllButtonsInScene();
    }

    private void HookAllButtonsInScene()
    {
        // ��Ȱ�� �����ؼ� ��� ã��
        var buttons = Object.FindObjectsByType<Button>(FindObjectsInactive.Include, FindObjectsSortMode.None);

        foreach (var b in buttons)
        {
            if (b == null) continue;

            int id = b.GetInstanceID();
            if (_hooked.Contains(id)) continue;

            _hooked.Add(id);

            // ��ư Ŭ�� �� ȿ���� ���
            b.onClick.AddListener(PlayClick);
        }
    }

    public void PlayClick()
    {
        if (clickClip == null || _source == null) return;
        _source.PlayOneShot(clickClip, volume);
    }
}
