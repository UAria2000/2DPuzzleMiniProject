using UnityEngine;
using UnityEngine.SceneManagement;

public class RunRestartManager : MonoBehaviour
{
    public static RunRestartManager I;

    [Header("���� ��ġ(LocationManager id)")]
    public string startLocationId = "Basement";

    private bool _restarting;

    private void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);
    }

    public void RestartRun()
    {
        if (_restarting) return;
        _restarting = true;

        Debug.Log("[RESTART] RestartRun called");

        Time.timeScale = 1f;

        // �κ� �ݱ�(�����ִ� ���·� ����ŸƮ ����)
        foreach (var t in Object.FindObjectsByType<InventoryToggle>(
                     FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            t.ForceClose();
        }

        // �̹� ȸ��(run)�� �ʱ�ȭ
        if (GameManager.I != null) GameManager.I.ClearInventory();
        if (FlagStore.I != null) FlagStore.I.ResetAll();
        if (TimeManager.I != null) TimeManager.I.ResetTime();
        if (NotePoolManager.I != null) NotePoolManager.I.ResetPool();
        if (EndingManager.I != null) EndingManager.I.ResetRunState();

        SceneManager.sceneLoaded -= OnSceneLoaded_AfterRestart;
        SceneManager.sceneLoaded += OnSceneLoaded_AfterRestart;

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    private void OnSceneLoaded_AfterRestart(Scene scene, LoadSceneMode mode)
    {
        SceneManager.sceneLoaded -= OnSceneLoaded_AfterRestart;

        // Ž�� ������Ʈ �� ���� �ʱ�ȭ
        foreach (var s in Object.FindObjectsByType<SearchableObject>(
                     FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            s.ResetRunState();
        }

        // ���� ��ġ ����
        if (LocationManager.I != null)
            LocationManager.I.Show(startLocationId);

        // ���� UI ����(������)
        if (UIEnding.I != null)
            UIEnding.I.Hide();

        // �κ� �ݱ�(����)
        foreach (var t in Object.FindObjectsByType<InventoryToggle>(
                     FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            t.ForceClose();
        }

        _restarting = false;
        Debug.Log("[RESTART] Done");
    }
}
