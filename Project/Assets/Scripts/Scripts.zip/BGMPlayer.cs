using System.Collections;
using UnityEngine;

public class BGMPlayer : MonoBehaviour
{
    public static BGMPlayer I;

    public AudioSource source;
    public float defaultFadeTime = 0.5f;
    public float maxVolume = 1f;

    private Coroutine _co;

    private AudioClip _current;
    private AudioClip _lastMapClip;

    public bool OverrideActive { get; private set; }
    public AudioClip OverrideClip { get; private set; }

    private void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);

        if (source == null)
        {
            source = GetComponent<AudioSource>();
            if (source == null) source = gameObject.AddComponent<AudioSource>();
        }

        source.loop = true;
        source.playOnAwake = false;
        source.volume = Mathf.Clamp01(maxVolume);
    }

    //  �ʿ��� ȣ���ϴ� BGM (4�ð� ���ĸ� ����)
    public void PlayMap(AudioClip clip, float fadeTime = -1f)
    {
        if (clip == null) return;

        _lastMapClip = clip;

        if (OverrideActive) return; // �������̵� �߿� �� BGM ����
        PlayInternal(clip, fadeTime);
    }

    //  �ð� �������� ���� ����ϴ� BGM
    public void PlayOverride(AudioClip clip, float fadeTime = -1f)
    {
        if (clip == null) return;

        OverrideActive = true;
        OverrideClip = clip;
        PlayInternal(clip, fadeTime);
    }

    //  ����� ������ �������̵� ����(��BGM�� ����)
    public void ClearOverride(float fadeTime = -1f)
    {
        OverrideActive = false;
        OverrideClip = null;

        if (_lastMapClip != null)
            PlayInternal(_lastMapClip, fadeTime);
    }

    private void PlayInternal(AudioClip clip, float fadeTime)
    {
        if (_current == clip && source.isPlaying) return;

        if (fadeTime < 0f) fadeTime = defaultFadeTime;

        if (_co != null) StopCoroutine(_co);
        _co = StartCoroutine(CoFadeTo(clip, fadeTime));
    }

    private IEnumerator CoFadeTo(AudioClip next, float fade)
    {
        float startVol = source.volume;

        if (source.isPlaying && fade > 0f)
        {
            for (float t = 0; t < fade; t += Time.unscaledDeltaTime)
            {
                source.volume = Mathf.Lerp(startVol, 0f, t / fade);
                yield return null;
            }
        }

        source.volume = 0f;
        _current = next;
        source.clip = next;
        source.Play();

        float target = Mathf.Clamp01(maxVolume);
        if (fade > 0f)
        {
            for (float t = 0; t < fade; t += Time.unscaledDeltaTime)
            {
                source.volume = Mathf.Lerp(0f, target, t / fade);
                yield return null;
            }
        }

        source.volume = target;
        _co = null;
    }
}
