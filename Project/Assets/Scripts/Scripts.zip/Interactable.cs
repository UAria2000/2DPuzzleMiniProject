using System.Collections.Generic;
using UnityEngine;

public class Interactable : MonoBehaviour
{
    [System.Serializable]
    public class Rule
    {
        public string name;

        public List<string> requireItems = new();
        public List<string> forbidItems = new();

        public int timeCost = 0;

        public string setFlag;      // �ܼ�ȭ�� ���� 1����
        public string requireFlag;  // �ܼ�ȭ�� ���� 1����

        public string triggerEndingId; // ��������� ���� ����
    }

    public List<Rule> rules = new();

    public void Interact()
    {
        foreach (var r in rules)
        {
            if (!string.IsNullOrEmpty(r.requireFlag) && !FlagStore.I.Has(r.requireFlag))
                continue;

            bool ok = true;

            foreach (var it in r.requireItems)
                if (!GameManager.I.HasItem(it)) ok = false;

            foreach (var it in r.forbidItems)
                if (GameManager.I.HasItem(it)) ok = false;

            if (!ok) continue;

            TimeManager.I.Spend(r.timeCost);

            if (!string.IsNullOrEmpty(r.setFlag))
                FlagStore.I.Set(r.setFlag);

            if (!string.IsNullOrEmpty(r.triggerEndingId))
                EndingManager.I.Trigger(r.triggerEndingId);

            return;
        }

        Debug.Log("���� ������: �ƹ� ��Ģ�� ������� ����");
    }
}
