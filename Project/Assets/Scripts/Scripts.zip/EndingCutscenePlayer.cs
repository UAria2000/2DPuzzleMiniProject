using System;
using UnityEngine;
using UnityEngine.Video;

public class EndingCutscenePlayer : MonoBehaviour
{
    public static EndingCutscenePlayer I;

    [Header("�ƽ� ��� ���� ID")]
    public string targetEndingId = "GoBackHomeSafty";

    [Header("����� ���� Ŭ��")]
    public VideoClip clip;

    [Header("�ƽ� UI �г�(�Ѱ�/���� �뵵)")]
    public GameObject panel;

    [Header("VideoPlayer")]
    public VideoPlayer player;

    [Header("��ŵ")]
    public bool allowSkip = true;
    public KeyCode skipKey = KeyCode.Space;

    private Action _onFinished;
    private bool _playing;

    private void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;

        // �� ������ص� ���������� ���� ������ �ѱ�(����)
        // DontDestroyOnLoad(gameObject);

        if (panel != null) panel.SetActive(false);
    }

    private void OnEnable()
    {
        if (player != null)
            player.loopPointReached += OnVideoEnd;
    }

    private void OnDisable()
    {
        if (player != null)
            player.loopPointReached -= OnVideoEnd;
    }

    private void Update()
    {
        if (!_playing) return;
        if (!allowSkip) return;

        if (Input.GetKeyDown(skipKey))
            Finish();
    }

    public bool HasCutscene(string endingId)
    {
        return endingId == targetEndingId && clip != null && player != null && panel != null;
    }

    public void Play(string endingId, Action onFinished)
    {
        if (!HasCutscene(endingId))
        {
            onFinished?.Invoke();
            return;
        }

        _onFinished = onFinished;
        _playing = true;

        // �ƽ��� ���� �ð����� ���
        Time.timeScale = 1f;

        panel.SetActive(true);

        player.clip = clip;
        player.Stop();
        player.Play();
    }

    private void OnVideoEnd(VideoPlayer vp) => Finish();

    private void Finish()
    {
        if (!_playing) return;
        _playing = false;

        if (player != null) player.Stop();
        if (panel != null) panel.SetActive(false);

        var cb = _onFinished;
        _onFinished = null;
        cb?.Invoke();
    }
}
