using System;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager I;

    private HashSet<string> _items = new();

    public event Action InventoryChanged;   //  �߰�

    private void Awake()
    {
        if (I != null) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);
    }

    public bool HasItem(string id) => _items.Contains(id);

    public void AddItem(string id)
    {
        _items.Add(id);

        // �κ� UI ����(������)
        if (UIInventory.I != null)
            UIInventory.I.Refresh(_items);

        // �κ� ���� �˸�
        InventoryChanged?.Invoke();
    }

    // (����) �� ȸ�� ���� �� ȣ���
    public void ClearInventory()
    {
        _items.Clear();
        if (UIInventory.I != null) UIInventory.I.Refresh(_items);
        InventoryChanged?.Invoke();
    }
}
