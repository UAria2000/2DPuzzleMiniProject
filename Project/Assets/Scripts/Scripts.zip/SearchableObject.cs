﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SearchableObject : MonoBehaviour
{
    [Header("디버그용 ID (각 탐색 오브젝트마다 고유 추천)")]
    public string objectId;

    [Header("탐색 시 소모 시간(분)")]
    public int searchCostMinutes = 10;

    [Header("이 오브젝트에서 쪽지 드랍 가능?")]
    public bool canDropNotes = true;

    [Header("이 오브젝트에서 1회성으로 나올 수 있는 아이템들(중복 X)")]
    public List<string> initialOneTimeItems = new();

    [Header("버튼(없으면 자동으로 GetComponent)")]
    public Button button;

    [Header("쪽지/아이템이 더 이상 안 나오면(쓰레기만 남으면) 호버/클릭 자체 막기")]
    public bool blockRaycastsWhenEmpty = true;

    // 런타임 상태
    private List<string> _remainingOneTimeItems;
    private bool _noteAlreadyDroppedHere;
    private CanvasGroup _cg;

    private enum ResultType { Trash, Note, Item }

    private struct Result
    {
        public ResultType type;
        public string itemId; // Item일 때만 사용
        public Result(ResultType t, string id = null) { type = t; itemId = id; }
    }

    private void Awake()
    {
        if (button == null) button = GetComponent<Button>();
        _cg = GetComponent<CanvasGroup>();

        // 방어: 인스펙터에서 리스트가 깨져 null로 들어오는 경우가 있음
        if (initialOneTimeItems == null) initialOneTimeItems = new List<string>();
    }

    private void Start()
    {
        // 첫 진입 시 런타임 리스트 준비 (ResetRunState는 “회차 리셋”용)
        EnsureRuntimeList();
        RefreshLockIfEmpty();
    }

    private void OnEnable()
    {
        // 맵 나갔다 들어올 때도 런타임 리스트가 null이면 다시 준비
        EnsureRuntimeList();
        RefreshLockIfEmpty();
    }

    private void EnsureRuntimeList()
    {
        if (initialOneTimeItems == null) initialOneTimeItems = new List<string>();

        if (_remainingOneTimeItems == null)
            _remainingOneTimeItems = new List<string>(initialOneTimeItems);
    }

    // “쓰레기 말고” 실제로 얻을 수 있는 것(쪽지/아이템)이 남아있는지
    public bool HasNonTrashRemaining()
    {
        EnsureRuntimeList();

        bool hasItems = _remainingOneTimeItems.Count > 0;

        bool notePossible =
            canDropNotes &&
            !_noteAlreadyDroppedHere &&
            NotePoolManager.I != null &&
            NotePoolManager.I.RemainingCount > 0;

        return hasItems || notePossible;
    }

    // ==========================
    // RandomUniqueItemAssigner 지원용 API
    // ==========================
    public void AddInitialOneTimeItem(string itemId)
    {
        if (string.IsNullOrEmpty(itemId)) return;

        if (initialOneTimeItems == null) initialOneTimeItems = new List<string>();
        if (!initialOneTimeItems.Contains(itemId))
            initialOneTimeItems.Add(itemId);

        // 런타임에도 즉시 반영
        EnsureRuntimeList();
        if (!_remainingOneTimeItems.Contains(itemId))
            _remainingOneTimeItems.Add(itemId);

        RefreshLockIfEmpty();
    }

    public void RemoveInitialOneTimeItem(string itemId)
    {
        if (string.IsNullOrEmpty(itemId)) return;

        if (initialOneTimeItems != null)
            initialOneTimeItems.Remove(itemId);

        if (_remainingOneTimeItems != null)
            _remainingOneTimeItems.Remove(itemId);

        RefreshLockIfEmpty();
    }

    // 새 회차 시작 시 호출(엔딩 재시작/타이틀 복귀 후 새 시작 등)
    public void ResetRunState()
    {
        if (initialOneTimeItems == null) initialOneTimeItems = new List<string>();

        _remainingOneTimeItems = new List<string>(initialOneTimeItems);
        _noteAlreadyDroppedHere = false;

        // 여기서 gameObject.SetActive(true) 하지 마세요 (상태 꼬일 수 있음)
        if (button != null) button.interactable = true;

        if (blockRaycastsWhenEmpty)
        {
            if (_cg == null) _cg = gameObject.AddComponent<CanvasGroup>();
            _cg.blocksRaycasts = true;
            _cg.interactable = true;
        }

        RefreshLockIfEmpty();
    }

    public void Search()
    {
        EnsureRuntimeList();

        // 시간 소모
        if (TimeManager.I != null)
            TimeManager.I.Spend(searchCostMinutes);

        // 가능한 결과 목록 만들기
        var results = new List<Result>();

        // 1) 남아있는 1회성 아이템들
        for (int i = 0; i < _remainingOneTimeItems.Count; i++)
            results.Add(new Result(ResultType.Item, _remainingOneTimeItems[i]));

        // 2) 쪽지(조건 만족 시만)
        bool notePossible =
            canDropNotes &&
            !_noteAlreadyDroppedHere &&
            NotePoolManager.I != null &&
            NotePoolManager.I.RemainingCount > 0;

        if (notePossible)
            results.Add(new Result(ResultType.Note));

        // 3) 쓰레기(항상 존재)
        results.Add(new Result(ResultType.Trash));

        // 무작위 선택
        int pick = Random.Range(0, results.Count);
        var chosen = results[pick];

        switch (chosen.type)
        {
            case ResultType.Trash:
                Debug.Log($"[SEARCH] {objectId}: 쓰레기(허탕)");
                break;

            case ResultType.Item:
                GiveItemOnce(chosen.itemId);
                break;

            case ResultType.Note:
                GiveNote();
                break;
        }

        RefreshLockIfEmpty();
    }

    private void GiveItemOnce(string itemId)
    {
        if (string.IsNullOrEmpty(itemId)) return;

        Debug.Log($"[SEARCH] {objectId}: 아이템 획득 {itemId}");

        if (GameManager.I != null)
            GameManager.I.AddItem(itemId);

        _remainingOneTimeItems.Remove(itemId);
    }

    private void GiveNote()
    {
        if (NotePoolManager.I == null) return;

        if (NotePoolManager.I.TryTakeRandomNote(out var noteId))
        {
            Debug.Log($"[SEARCH] {objectId}: 쪽지 획득 {noteId}");

            _noteAlreadyDroppedHere = true;

            if (GameManager.I != null)
                GameManager.I.AddItem(noteId);
        }
    }

    // “비었을 때만” 더 강하게 잠금(다른 스크립트의 해금 로직을 덮어쓰지 않음)
    private void RefreshLockIfEmpty()
    {
        EnsureRuntimeList();

        bool hasLoot = HasNonTrashRemaining();
        if (!hasLoot)
        {
            if (button != null)
                button.interactable = false;

            if (blockRaycastsWhenEmpty)
            {
                if (_cg == null) _cg = gameObject.AddComponent<CanvasGroup>();
                _cg.blocksRaycasts = false; // 호버/클릭 자체 차단
                _cg.interactable = false;
            }
        }
    }
}
