using UnityEngine;

public class MetaResetButton : MonoBehaviour
{
    public void ResetMeta()
    {
        if (MetaSave.I == null)
        {
            Debug.LogError("[MetaResetButton] MetaSave.I is null (���� MetaSave�� ���ų� Awake�� �� ������)");
            return;
        }

        MetaSave.I.ResetAllMeta();
        Debug.Log("[MetaResetButton] ResetMeta called");
    }
}
